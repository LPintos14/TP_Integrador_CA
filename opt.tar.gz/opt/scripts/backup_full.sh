#! /bin/bash

#1. Opcion -help

if [ "$1" == "-help"]; then
	echo "Uso: backup_full.sh <origen> <destino>"
	echo "Ejemplo: backup_full.sh /var/log /backup_dir"
	exit 0
fi

# 2. Validación de argumentos
if [ -z "$1" ] || [ -z "$2" ]; then
    echo "Error: Faltan argumentos. Use -help para ver la ayuda."
    exit 1
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
# Obtiene solo el nombre final del directorio (ej: /var/log -> log)
NOMBRE=$(basename "$ORIGEN")

# 3. Validación de existencia del origen
if [ ! -d "$ORIGEN" ]; then
    echo "Error: El origen $ORIGEN no existe."
    exit 1
fi

# 4. Validación de existencia del destino
if [ ! -d "$DESTINO" ]; then
    echo "Error: El destino $DESTINO no existe."
    exit 1
fi

# 5. Lógica de backup
# Crear el archivo tar.gz en el destino con el formato nombre_bkp_YYYYMMDD.tar.gz
ARCHIVO_FINAL="${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"

echo "Iniciando backup de $ORIGEN en $ARCHIVO_FINAL ..."

# Usamos tar -c (crear), -z (gzip), -f (archivo)
tar -czf "$ARCHIVO_FINAL" "$ORIGEN"

# Verificar si el comando anterior fue exitoso
if [ $? -eq 0 ]; then
    echo "Backup completado exitosamente: $ARCHIVO_FINAL"
else
    echo "Error durante el proceso de backup."
    exit 1
fi
